import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { Cat } from "@/components/Cat";
import { getCatFacts } from "@/features/catthunk";

import { ICat } from "@/features/cat/types";
export const Cats: React.FC = () => {
  const dispatch = useAppDispatch();
  const items = useAppSelector((state) => state.cat.items);
  useEffect(() => {
    dispatch(getCatFacts() as any);
  }, []);
  return (
    <>
      <h1>Cat Facts</h1>
      <ul>
        {items &&
          items.map((item: ICat) => (
            <li>
              <Cat {...item}></Cat>
            </li>
          ))}
      </ul>
    </>
  );
};
