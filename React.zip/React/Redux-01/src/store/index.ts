import { catReducer } from "@/features/cat";
import { createStore, applyMiddleware, combineReducers } from "redux";
import thunk from "redux-thunk";

export const store = createStore(
  combineReducers({ cat: catReducer }),
  applyMiddleware(thunk)
);

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
