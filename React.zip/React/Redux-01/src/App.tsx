import { useState } from "react";

import "./App.css";
import { Cats } from "./views/Cats";

function App() {
  return (
    <div className="App">
      <Cats />
    </div>
  );
}

export default App;
