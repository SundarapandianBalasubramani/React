import { Reducer } from "redux";
import {
  GET_CAT_FACTS,
  GET_CAT_FACTS_FAILURE,
  GET_CAT_FACTS_SUCCESS,
} from "../catthunk";
import { IAction, ICats } from "./types";

const initialState = {
  items: [],
  isFetching: false,
  isSuccess: false,
  isError: false,
  errorMessage: "",
} as ICats;

export function catReducer(state: ICats = initialState, action: IAction) {
  switch (action.type) {
    case GET_CAT_FACTS:
      return {
        isFetching: true,
        isSuccess: false,
        isError: false,
        errorMessage: "",
        items: [],
      };
    case GET_CAT_FACTS_SUCCESS:
      return {
        isFetching: false,
        isSuccess: true,
        isError: false,
        errorMessage: "",
        items: action.cats,
      };
    case GET_CAT_FACTS_FAILURE:
      return {
        isFetching: false,
        isSuccess: false,
        isError: true,
        errorMessage: action.err?.message,
        items: [],
      };
    default:
      return state;
  }
}
