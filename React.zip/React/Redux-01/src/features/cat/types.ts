export interface ICat {
  status: { verified: boolean; sentCount: number };
  _id: string;
  user: string;
  text: string;
  __v: number;
  source: string;
  updatedAt: string;
  type: string;
  createdAt: string;
  deleted: boolean;
  used: boolean;
}

export interface ICats {
  items: ICat[];
  isFetching: boolean;
  isSuccess: boolean;
  isError: boolean;
  errorMessage: string;
}

export interface IAction {
  type: string;
  cats?: ICat[];
  err?: Error;
}
