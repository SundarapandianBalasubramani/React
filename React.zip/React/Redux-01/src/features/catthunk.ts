import { AnyAction } from "redux";
import { ThunkDispatch } from "redux-thunk";
import { IAction, ICat } from "./cat/types";

export const GET_CAT_FACTS = "GET_CAT_FACTS";
export const GET_CAT_FACTS_SUCCESS = "GET_CAT_FACTS_SUCCESS";
export const GET_CAT_FACTS_FAILURE = "GET_CAT_FACTS_FAILURE";

export const getCatFacts = () => {
  return (dispatch: ThunkDispatch<{}, {}, AnyAction>) => {
    return fetch("https://cat-fact.herokuapp.com/facts/")
      .then((resp) => {
        return resp.json().then((cats) => {
          return dispatch({ type: GET_CAT_FACTS_SUCCESS, cats } as IAction);
        });
      })
      .catch((err) => {
        return dispatch({ type: GET_CAT_FACTS_FAILURE, err } as IAction);
      });
  };
};
