import { ICat } from "@/features/cat/types";
import React from "react";

export const Cat: React.FC<ICat> = (props) => {
  return <>{props.text}</>;
};
