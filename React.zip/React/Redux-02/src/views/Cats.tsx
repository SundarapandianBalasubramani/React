import React, { useEffect } from "react";
import { useAppDispatch, useAppSelector } from "@/store/hooks";
import { getCatFacts } from "@/features/cat";
import { Cat } from "@/components/Cat";
export const Cats: React.FC = () => {
  const dispatch = useAppDispatch();
  const items = useAppSelector((state) => state.cat.items);
  useEffect(() => {
    dispatch(getCatFacts());
  }, []);
  return (
    <>
      <h1>Cat Facts</h1>
      <ul>
        {items.map((item) => (
          <li>
            <Cat {...item}></Cat>
          </li>
        ))}
      </ul>
    </>
  );
};
