import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { ICat, ICats } from "./types";

export const getCatFacts = createAsyncThunk(
  "cats",
  async (): Promise<ICat[]> => {
    try {
      const response = await fetch("https://cat-fact.herokuapp.com/facts/");
      return await response.json();
    } catch (e) {
      throw e;
    }
  }
);

const initialState = {
  items: [],
  isFetching: false,
  isSuccess: false,
  isError: false,
  errorMessage: "",
} as ICats;

export const catSlice = createSlice({
  name: "cats",
  initialState,
  reducers: {
    clearCatState: (state) => {
      state.isError = false;
      state.isSuccess = false;
      state.isFetching = false;
      state.items = [];
      state.errorMessage = "";
      return state;
    },
  },
  extraReducers: (builder) => {
    builder.addCase(getCatFacts.fulfilled, (state, action) => {
      if (action.payload) {
        state.items = action.payload;
        state.isFetching = false;
        state.isSuccess = true;
      }
    });
    builder.addCase(getCatFacts.rejected, (state, action) => {
      state.isFetching = false;
      state.isError = true;
      state.errorMessage = String(action.error.message);
    });
    builder.addCase(getCatFacts.pending, (state, action) => {
      state.isFetching = true;
    });
  },
});

export const { clearCatState } = catSlice.actions;
