import { configureStore } from "@reduxjs/toolkit";
import { catSlice } from "@/features/cat";
export const store = configureStore({
  reducer: {
    cat: catSlice.reducer,
  },
  middleware: (getDefaultMiddleware) => {
    return getDefaultMiddleware();
  },
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
