import { configureStore } from "@reduxjs/toolkit";
import { catsApi } from "@/features/cat";
export const store = configureStore({
  reducer: {
    [catsApi.reducerPath]: catsApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware().concat(catsApi.middleware),
});

export type AppDispatch = typeof store.dispatch;
export type RootState = ReturnType<typeof store.getState>;
