import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { ICat } from "./types";

type CatsResponse = ICat[];

export const catsApi = createApi({
  baseQuery: fetchBaseQuery({
    baseUrl: "https://cat-fact.herokuapp.com/",
  }),
  endpoints: (build) => ({
    getCatFacts: build.query<CatsResponse, void>({
      query: () => "facts",
      keepUnusedDataFor: 5,
    }),
  }),
});

export const { useGetCatFactsQuery } = catsApi;
