import React from "react";
import { useGetCatFactsQuery } from "@/features/cat";
import { Cat } from "@/components/Cat";
export const Cats: React.FC = () => {
  const { data, error, isLoading } = useGetCatFactsQuery();

  return (
    <>
      <h1>Cat Facts</h1>
      <ul>
        {data &&
          data.map((item) => (
            <li>
              <Cat {...item}></Cat>
            </li>
          ))}
      </ul>
    </>
  );
};
