const { webpackMerge, htmlOverlay, webpackServeConfig } = require('just-scripts');
webpackServeConfig.devServer = {
    https: true,
    port: 9000,
    allowedHosts: [
        '.sharepoint.com'
      ]
}
module.exports = webpackMerge(webpackServeConfig, htmlOverlay);
