const { webpackConfig } = require('just-scripts');
module.exports = webpackConfig;

