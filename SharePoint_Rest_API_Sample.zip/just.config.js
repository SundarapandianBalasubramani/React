// @ts-check
const { taskPresets } = require('just-scripts');
taskPresets.webapp();
