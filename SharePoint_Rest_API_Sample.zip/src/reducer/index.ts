import { IAppState } from '../types';
import { Reducer } from "redux";
import { DATA, Request } from '../constants';
import { IAction } from '../actions';
const appReducer: Reducer = (appState: IAppState, action: IAction): IAppState => {
  switch (action.type) {
    case Request:
      return {
        ...appState,
        digest: action.payload
      };
    case DATA:
      return {
        ...appState,
        cast: action.payload.cast,
        content: action.payload.content,
        quotes: action.payload.quotes,
        songs: action.payload.songs,
      };

  }
  return appState;
};
export default appReducer;
