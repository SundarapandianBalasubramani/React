export interface ILink{
    link:string,
    text:string,
    key:number
}
export interface IAppState{
    content?: any,
    links?: ILink[],
    cast?:any[],
    quotes?:any[],
    songs?:any[],
    digest?:string,
    images?:any[],
}
export interface IAppProps extends IAppState{
    GetFormDigest(digest: string):void,
    GetItems(state: IAppState):void,
}
export interface IActions{
    type: string,
    payload: any
}
export interface IBatchRequestHeaders{
    'X-RequestDigest':string,
    'Content-Type':string
}
export interface IContextInfo{
    d:IContextData
}
export interface IContextData{
    GetContextWebInformation:IGetContextWebInformation,
    "__metadata": IMetaData,
}
export interface IGetContextWebInformation{
    FormDigestTimeoutSeconds:number,
    FormDigestValue:string,
    LibraryVersion:string,
    SiteFullUrl:string,
    WebFullUrl:string,
    SupportedSchemaVersions:ISupportedSchemaVersions,
}
export interface IMetaData{
    "__metadata": IType
}
export interface IType{
    type:string
}
export interface ISupportedSchemaVersions{
    "__metadata": IMetaData,
    results:string[]
}
