import React from 'react';
import ReactDOM from 'react-dom';
import  Root from './container/Root';
import { Provider } from 'react-redux'
import store from '../src/store';
import './styles/styles.scss';
ReactDOM.render(
    <Provider store={store}>
      <Root  />
    </Provider>,
  document.getElementById('app'));