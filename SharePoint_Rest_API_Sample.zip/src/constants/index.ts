export const Relative_URL = "/teams/Demo",
 batchEndPoint ="/_api/$batch",
 replaceString = "listName",
 spList = ['Main','Coco','Quotes','Songs','Images'],
 getListItemEndPoint = `/_api/web/lists/getbytitle('${replaceString}')/items`,
 contextInfo = '/_api/contextinfo';
 export const spLists = [
   "/_api/web/lists/getbytitle('Main')/items?$select=Title, OData__Source, Keywords, ImageId",
   "/_api/web/lists/getbytitle('Coco')/items?$select=Title, OData__Source, Keywords, ImageId",
   "/_api/web/lists/getbytitle('Quotes')/items?$select=Title, ImageId, RelatedId",
   "/_api/web/lists/getbytitle('Songs')/items?$select=Title, ImageId, RelatedId",
   "/_api/web/lists/getbytitle('Images')/items?$$Select=EncodedAbsUrl, EncodedAbsThumbnailUrl, EncodedAbsWebImgUrl, ID"
  ];
 export const DATA = "Data";
 export type DATA = typeof DATA;
 export const Request ='Request';
 export type Request = typeof Request;