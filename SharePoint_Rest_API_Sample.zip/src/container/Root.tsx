import { Root } from '../components/Root';
import { IAppState } from '../types';
import { connect } from 'react-redux';
import * as actions from '../actions/';
import {Dispatch} from 'redux';
const mapReduxState = (state: IAppState) => {
  return {
    ...state
  };
}

const mapReduxDispatch = (dispatch:Dispatch<actions.IAction>) => {
  return {
    GetFormDigest: (digest:string) => dispatch(actions.RequestDigest(digest)),
    GetItems: (appState: IAppState) => dispatch(actions.Items(appState))
  };
};

export default connect(mapReduxState, mapReduxDispatch)(Root);