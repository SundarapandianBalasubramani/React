import * as constants from '../constants';
import { IAppState } from '../types';
import * as XHR from '../data/xhr';
import * as data from '../data';

export const Items = (state:IAppState):IItems =>(
    { type: constants.DATA, payload :state }
);

export const RequestDigest = (digest:string):IRequestDigest => (
    {type: constants.Request , payload: digest}
);

export interface IItems {
    type: constants.DATA,
    payload: IAppState
}

export interface IRequestDigest {
    type: constants.Request,
    payload: string
}

export type IAction = IItems | IRequestDigest;

export const GetDigest = ():Promise<any> =>{
    return XHR.Post(constants.Relative_URL + constants.contextInfo, '' ,  data.defaultHeaders);
};

export const GetItems = (digest:string):Promise<any> =>{
    const batchid = data.generateUUID();
    const batchHeaders = data.getBatchRequestHeader(digest, batchid);
    const postData = data.getMultipleListsData(batchid, constants.Relative_URL, constants.spLists);
    return  XHR.Post(constants.Relative_URL +  constants.batchEndPoint, postData ,  batchHeaders);
}