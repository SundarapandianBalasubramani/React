import axios from 'axios';
export const Post=(URL:string, postBody:any, requestHeader:any):Promise<any>=>{
   return axios.post(URL , postBody, {headers: requestHeader});
}
export const Get =(URL:string,  requestHeader:any):Promise<any>=>{
  return axios.get(URL , {headers: requestHeader});
}