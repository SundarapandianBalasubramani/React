import {IBatchRequestHeaders} from '../types';
export const generateUUID =(): string =>{
  let dateTime = new Date().getTime();
  const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
    let random = (dateTime + Math.random() * 16) % 16 | 0;
    dateTime = Math.floor(dateTime / 16);
    return (c == 'x' ? random : (random & 0x7 | 0x8)).toString(16);
  });
  return uuid;
}
export const getMultipleListsData=(batchGuid:string, Relative_URL:string, spLists:string[]):string=>{
  let batchContents:string[] = [];
  spLists.forEach((list) =>{
    batchContents.push('--batch_' + batchGuid);
    batchContents.push('Content-Type: application/http');
    batchContents.push('Content-Transfer-Encoding: binary');
    batchContents.push('');
    batchContents.push('GET ' + Relative_URL +  list + ' HTTP/1.1');
    batchContents.push('Accept: application/json;odata=verbose');
    batchContents.push('');
  });
  batchContents.push('--batch_' + batchGuid + '--');
  return batchContents.join('\r\n');
}
export const getBatchRequestHeader = (formDigest:string, batchGuid:string):IBatchRequestHeaders=>{
  return {
    'X-RequestDigest': formDigest,
    'Content-Type': 'multipart/mixed; boundary="batch_' + batchGuid + '"'
  };
}
export const defaultHeaders = {
  'Accept': 'application/json;odata=verbose'
}


