import React from "react";
import {  ILink } from '../types';
import { Link } from "react-router-dom";
interface IProps{
    links?: ILink[];
}
export const Header: React.FunctionComponent<IProps> = (props) => {
  return (
    <nav>
      <ul>
        { props.links !== undefined ? props.links.map(link => { return <li key={link.link}><Link to={link.link}>{link.text}</Link></li>}) :""}
      </ul>
    </nav>
  );
};
