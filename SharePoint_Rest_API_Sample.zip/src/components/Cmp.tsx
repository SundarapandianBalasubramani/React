import React from "react";
interface IProps{
    txt?:string;
}
export const Cmp: React.FunctionComponent<IProps>= (props) => {
   let txt= props.txt!== undefined ? props.txt:"Test";
   console.log(props.txt);
  return (
    <h1>{txt}</h1>
  );
};