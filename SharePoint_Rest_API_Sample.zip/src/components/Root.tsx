import React from "react";
import { Header } from "../components/Header";
import { IAppState, IAppProps } from "../types";
import { BrowserRouter as Router, Route } from "react-router-dom";
import { GetItems } from "../actions";
import {Cmp} from '../components/Cmp';
import { Link } from "react-router-dom";
export class Root extends React.Component<IAppProps, {}> {
  constructor(props: IAppProps) {
    super(props);
  }

  componentDidMount() {
   // this.getData();
  }

  private parseSPData() {
    try {
      const SPData = window.sessionStorage.getItem("SPData") as string;
      var responseInLines = SPData.split("\r\n");
      let tryParseJson = responseInLines[0];
      let responseData = JSON.parse(tryParseJson);
      let data = responseData.data;
      this.assignDataToStore(data);
    } catch (e) {
      console.log(e);
    }
  }

  private assignDataToStore(data: string) {
    var allResponses = data.split("\n");
    let datacount = 0;
    const storeData: IAppState = {};
    for (let i = 0; i < allResponses.length; i++) {
      let spdata = allResponses[i] as string;
      if (spdata.startsWith('{"d":{"results"')) {
        const listdata: any = JSON.parse(spdata);
        console.log(listdata);
        switch (datacount) {
          case 0:
            storeData.content = listdata.d.results;
            break;
          case 1:
            storeData.cast = listdata.d.results;
            break;
          case 2:
            storeData.quotes = listdata.d.results;
            break;
          case 3:
            storeData.songs = listdata.d.results;
            break;
          case 4:
            storeData.links = listdata.d.results;
            break;
          case 5:
            storeData.images = listdata.d.results;
            break;
        }
        datacount++;
      }
    }
    console.log(storeData);
  }

  private async getData() {
    try {
      const SPData = window.sessionStorage.getItem("SPData");
      if (SPData === null || SPData === undefined) {
        let REQUESTDIGEST = (document.getElementById(
          "__REQUESTDIGEST"
        ) as HTMLInputElement).value;
        const itemsResponse = await GetItems(REQUESTDIGEST);
        window.sessionStorage.setItem("SPData", JSON.stringify(itemsResponse));
        this.parseSPData();
      } else {
        this.parseSPData();
      }
    } catch (error) {
      console.log(error);
    }
  }

  render() {
    return (
      <Router>
      <div>
        <nav>
          <ul>
            <li key={"Coco"}>
              <Link to="/teams/Demo/Coco">Coco</Link>
            </li>
            <li key={"Miguel"}>
              <Link to="/teams/Demo/Miguel">Miguel</Link>
            </li>
            <li key={"Ernesto"}>
              <Link to="/teams/Demo/Ernesto">Ernesto</Link>
            </li>
             <li key={"Hector"}>
              <Link to="/teams/Demo/Hector">Hector</Link>
            </li>
              <li key={"Imelda"}>
              <Link to="/teams/Demo/Imelda">Imelda</Link>
            </li>
          </ul>
        </nav>
        <Route path="/teams/Demo/Coco"  render={()=><Cmp txt="Coco"/>}/>
        <Route path="/teams/Demo/Miguel"  render={()=><Cmp txt="Miguel"/>}/>
        <Route path="/teams/Demo/Ernesto"  render={()=><Cmp txt="Ernesto"/>}/>
        <Route path="/teams/Demo/Hector"  render={()=><Cmp txt="Hector"/>}/>
        <Route path="/teams/Demo/Imelda"   render={()=><Cmp txt="Imelda"/>}/>
      </div>
    </Router>
    );
  }
}
