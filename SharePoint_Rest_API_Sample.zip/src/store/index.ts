import {createStore} from "redux";
import appReducer from "../reducer";
import { Relative_URL } from '../constants';
import { IAppState, ILink } from '../types';
import { IAction } from '../actions';
const navLinks: ILink[] = [
    { link: Relative_URL + "/Coco", text: "Home", key:1}
  , { link: Relative_URL + "/Miguel", text: "Miguel", key:2}
  , { link: Relative_URL + "/Imelda", text: "Imelda", key:3}
  , { link: Relative_URL + "/Ernesto", text: "Ernesto", key:4 }
  , { link: Relative_URL + "/Hector", text: "Hector", key:5 }
];
const initialState: IAppState = {
    links: navLinks,
    cast: [],
    content: "",
    quotes: [],
    songs: [],
    digest: ""
  }
const store = createStore<IAppState, IAction, unknown, unknown>(appReducer, {...initialState});
export default store;
